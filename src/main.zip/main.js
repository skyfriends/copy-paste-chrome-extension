import React from 'react';
import ReactDom from 'react-dom';
import './style/main.scss';
import App from './component/app';

ReactDom.render(<App />, document.getElementById('root'));
